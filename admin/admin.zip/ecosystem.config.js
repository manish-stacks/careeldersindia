module.exports = {
  apps: [
    {
      name: "projectname",
      script: "npm",
      args: "start",
      cwd: "/root/projectrootname",
      env: {
        NODE_ENV: "production",
      },
    },
  ],
};