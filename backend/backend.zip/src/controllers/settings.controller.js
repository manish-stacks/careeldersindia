const { z } = require('zod');
const { asyncHandler } = require('../utils/asyncHandler');
const { ok } = require('../utils/response');
const Setting = require('../models/Setting');
const notifications = require('../services/notification.service');

const DEFAULTS = {
  email: 'support@careeldersindia.com',
  phone: '',
  whatsapp: '',
  address: '',
  website: 'https://careeldersindia.com',
  hours: '',
};

const text = (max) => z.string().trim().max(max).optional().or(z.literal(''));
const contactSchema = z.object({
  email: z.string().trim().email().max(120).optional().or(z.literal('')),
  phone: text(30),
  whatsapp: text(30),
  address: text(300),
  website: text(120),
  hours: text(120),
});

const enquirySchema = z.object({
  name: z.string().trim().min(2).max(100),
  email: z.string().trim().email().max(120),
  phone: text(30),
  message: z.string().trim().min(10).max(1500),
});

async function read() {
  const doc = await Setting.findOne({ key: 'contact' }).lean();
  return { ...DEFAULTS, ...(doc?.value || {}) };
}

module.exports = {
  contactSchema,
  enquirySchema,
  // Public website contact form → notifies every admin
  enquiry: asyncHandler(async (req, res) => {
    const { name, email, phone, message } = req.body;
    await notifications.notifyAdmins({ type: 'WEB_ENQUIRY', title: `Website enquiry from ${name}`, body: `${message}\n\nEmail: ${email}${phone ? `\nPhone: ${phone}` : ''}`.slice(0, 1800), data: { email, phone: phone || '' }, push: false });
    ok(res, {}, 'Thank you. Our care desk will contact you shortly.');
  }),
  getContact: asyncHandler(async (_req, res) => ok(res, await read())),
  updateContact: asyncHandler(async (req, res) => {
    const value = { ...(await read()), ...req.body };
    await Setting.findOneAndUpdate({ key: 'contact' }, { value }, { upsert: true, new: true });
    ok(res, value, 'Contact details updated');
  }),
};
